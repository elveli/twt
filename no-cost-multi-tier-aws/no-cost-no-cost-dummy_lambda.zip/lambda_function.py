def handler(event, context):
    return "Hello from no-cost Lambda!"
